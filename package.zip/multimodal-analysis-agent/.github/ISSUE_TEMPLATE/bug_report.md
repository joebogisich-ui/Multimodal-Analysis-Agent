---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 3046022100ea7af015567e58c51cdf57cd2367e074a72cd809e037e7f451767cf1ba8187220221009832620f449bf4acac8b99e7c0b470617d4c6e8859ee8a08a7db7250e28fd60f
    ReservedCode2: 3044022100f6732a9280af708b1e476f421dc10515452505c75c40fcfb9c7091760fbfafb7021f5467643db67cb6f40dddc0d62c77f5da2bf9b3e22c9e87d00798d39d61a225
about: Create a report to help us improve
assignees: ""
labels: bug
name: Bug report
title: '[BUG] '
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear description of what you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain your problem.

**Desktop (please complete the following information):**
 - OS: [e.g. macOS, Linux]
 - Browser [e.g. chrome, safari]
 - Version [e.g. 1.0.0]

**Additional context**
Add any other context about the problem here.
